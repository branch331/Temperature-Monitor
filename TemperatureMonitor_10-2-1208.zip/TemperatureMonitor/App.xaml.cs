﻿using System.Windows;

namespace NationalInstruments.Examples.BoardTemperatureMonitor
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
